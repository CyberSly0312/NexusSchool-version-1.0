<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        $this->call([
            SchoolSeeder::class,
            PlanSeeder::class,
            RoleSeeder::class,
            PermissionSeeder::class,
            AcademicYearSeeder::class,
            AcademicTermSeeder::class,
            DepartmentSeeder::class,
            ProgramSeeder::class,
            GradeLevelSeeder::class,
            SectionSeeder::class,
            AcademicClassSeeder::class,
            ClassroomSeeder::class,
            SubjectCategorySeeder::class,
            SubjectSeeder::class,
            SubjectCoefficientSeeder::class,
            GuardianSeeder::class,
            StudentSeeder::class,
            StudentEnrollmentSeeder::class,
            UserSeeder::class,
            AssessmentSeeder::class,
            AssessmentResultSeeder::class,
            AuthorSeeder::class,
            PublisherSeeder::class,
            BookCategorySeeder::class,
            BookSeeder::class,
            BookCopySeeder::class,
            BookLoanSeeder::class,
            ReservationSeeder::class,
            FineSeeder::class,
            VehicleSeeder::class,
            DriverSeeder::class,
            RouteSeeder::class,
            RouteStopSeeder::class,
            TripSeeder::class,
            StudentTransportAssignmentSeeder::class,
            VehicleMaintenanceSeeder::class,
            FuelLogSeeder::class,
            NotificationTemplateSeeder::class,
            NotificationSeeder::class,
            NotificationDeliverySeeder::class,
            AnnouncementSeeder::class,
            CommunicationChannelSeeder::class,
            MessageSeeder::class,
            DashboardSeeder::class,
            DashboardWidgetSeeder::class,
            ReportSeeder::class,
            KpiSeeder::class,
            AnalyticsSnapshotSeeder::class,
            ApiClientSeeder::class,
            WebhookSeeder::class,
        ]);
    }
}

<?php

declare(strict_types=1);

namespace App\Domains\Ai\Events;

use App\Models\AiConversation;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ConversationStarted
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        public readonly AiConversation $conversation,
    ) {
    }
}

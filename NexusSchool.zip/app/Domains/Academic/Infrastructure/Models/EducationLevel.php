<?php

declare(strict_types=1);

namespace App\Domains\Academic\Infrastructure\Models;

use App\Domains\Academic\Domain\Enums\EntityStatus;
use App\Traits\HasSchoolId;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class EducationLevel extends Model
{
    use HasFactory;
    use HasSchoolId;
    use SoftDeletes;

    protected $fillable = [
        'school_id',
        'name',
        'code',
        'sort_order',
        'description',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'status' => EntityStatus::class,
            'sort_order' => 'integer',
        ];
    }

    public function programs(): HasMany
    {
        return $this->hasMany(AcademicProgram::class, 'education_level_id');
    }

    public function streams(): HasMany
    {
        return $this->hasMany(Stream::class, 'education_level_id');
    }

    public function classes(): HasMany
    {
        return $this->hasMany(SchoolClass::class, 'education_level_id');
    }
}

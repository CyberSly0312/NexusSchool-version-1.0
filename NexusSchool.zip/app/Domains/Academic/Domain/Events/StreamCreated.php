<?php

declare(strict_types=1);

namespace App\Domains\Academic\Domain\Events;

use App\Domains\Academic\Infrastructure\Models\Stream;
use App\Models\User;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class StreamCreated
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        public readonly Stream $stream,
        public readonly ?User $actor = null,
    ) {
    }
}

<?php

declare(strict_types=1);

namespace App\Domains\AcademicTerm\Events;

use App\Models\AcademicTerm;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class AcademicTermArchived
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        public readonly AcademicTerm $academicTerm,
    ) {
    }
}
